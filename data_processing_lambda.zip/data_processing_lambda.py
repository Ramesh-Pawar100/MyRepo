import boto3
import os
import json
import requests

"""
This lambda function will read the data from source bucket and send  top 10 rank movies details to SQS Queue.
This function can be invoked using s3 object put event for source file. 
"""
def lambda_handler(event, context):
    ##Read the s3 data
    imdb_data=requests.get("https://top-movies.s3.eu-central-1.amazonaws.com/Top250Movies.json")
    top10_list=[]
    if imdb_data.ok:
        for i in range(10):
            top10_list.append(json.loads(imdb_data.text)["items"][i])

    else:
        raise Exception('Unable to connect to source S3 bucket!!')


    ##Create connection to AWS SQS to push messages  
    client=boto3.client("sqs","us-east-1")
    #print(os.environ["access_key"])
    #print(os.environ["secret_key"])
    for msg in top10_list:
        #print(msg)
        client.send_message(QueueUrl="https://sqs.us-east-1.amazonaws.com/775718998281/MyImDBQueue",MessageBody=json.dumps(msg)) 

