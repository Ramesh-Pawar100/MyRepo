import json
import requests
import boto3

"""
This function will read the message from SQS Queue and call API to get some additional details.
Result will be stored in s3 bucket.
"""
def lambda_handler(event, context):
    client=boto3.client("s3","us-east-1")
    client1=boto3.client("ssm","us-east-1")
    for record in event["Records"]:
        print(record["body"])
        msg_dtl=json.loads(record["body"])
        movie_id=msg_dtl["id"]
        key_id=client1.get_parameter(Name="imdb_key")["Parameter"]["Value"]
        response=requests.get("http://www.omdbapi.com/?i="+movie_id+"&apikey="+key_id)
        if response.ok:
            enriched_data=response.text
            client.put_object(Body=enriched_data,Bucket="myimdbbucket82",Key="output/"+movie_id+"_data.json")
        else:
            raise Exception("Unable to get data from IMDB API")
            
